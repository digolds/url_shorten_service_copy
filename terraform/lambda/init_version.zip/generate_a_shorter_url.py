import boto3
import os

def generate_a_shorter_url(event, context): 
    return { 
        'message' : "Hello from generate a shorter url"
    }